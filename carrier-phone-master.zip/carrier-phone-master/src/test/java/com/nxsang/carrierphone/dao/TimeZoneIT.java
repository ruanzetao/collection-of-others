//package com.nxsang.carrierphone.dao;
//
//import java.util.List;
//
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.google.common.collect.Lists;
//import com.nxsang.carrierphone.config.ConfigITContext;
//import com.nxsang.carrierphone.domain.TimeZone;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = { ConfigITContext.class })
//public class TimeZoneIT {
//
//    @Autowired 
//    private TimeZoneDAO timeZoneDao;
//    
//    @Test
//    public void save_success_timezone() {
//        TimeZone timeZone=new TimeZone();
//        
//        timeZone.setName("kimochii");
//        timeZone.setIsdst(true);
//        timeZone.setAbbr("yame");
//        timeZone.setUtcOffset("ABC");
//        
//        timeZoneDao.save(timeZone);
//        
//        //Then
//        List<TimeZone> timeZones = Lists.newArrayList(timeZoneDao.findAll());
//        Assert.assertEquals(2, timeZones.size());
//    }
//}
//
