package com.nxsang.carrierphone.domain.dto;

import com.nxsang.carrierphone.domain.CountryDetail;

public class CountryDetailDto {

	private String capital;
	private String region;

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public static CountryDetailDto toDto(CountryDetail detail) {
		CountryDetailDto c = new CountryDetailDto();
        c.setCapital(detail.getCapital());
        c.setRegion(detail.getRegion());
        return c;
    }
}
