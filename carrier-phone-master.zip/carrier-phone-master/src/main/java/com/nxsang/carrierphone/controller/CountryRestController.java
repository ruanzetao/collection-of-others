package com.nxsang.carrierphone.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nxsang.carrierphone.domain.Country;
import com.nxsang.carrierphone.domain.dto.CountryDto;
import com.nxsang.carrierphone.service.CountryService;

@Controller
public class CountryRestController {
    @Autowired
    private CountryService countryService;
    
    @RequestMapping(name = "/countries", method = RequestMethod.GET)
    public ResponseEntity<List<CountryDto>> getAllTickets() {
        List<Country> countries = countryService.findAll();
        List<CountryDto> countriesDto = countries.stream().map(country -> CountryDto.toDto(country))
                .collect(Collectors.toList());
        return ResponseEntity.ok(countriesDto);
    }
    
    //@PostMapping("/country")
    public Country createCountry(@RequestBody Country country) {
        Country savedCountry=countryService.createCountry(country);
        return savedCountry;
    }
    /**
     * 
     * new Function<Country, CountryDto>() {

            @Override
            public CountryDto apply(Country country) {
                return CountryDto.toDto(country);
            }
        }
     */
    

//    @RequestMapping(name = "/countries", method = RequestMethod.POST)
//    @ResponseStatus(code = HttpStatus.CREATED)
//    public void addCountry(@RequestBody CountryDTO countryDTO) {
//        countryService.createCountry(country);
//    }
}