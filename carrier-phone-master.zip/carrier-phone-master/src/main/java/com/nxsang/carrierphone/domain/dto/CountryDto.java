package com.nxsang.carrierphone.domain.dto;

import com.nxsang.carrierphone.domain.Country;

public class CountryDto {
    
    private String name;
    private String code2Digit;
    private String code3Digit;
    private Integer isoCode;
    private String callingCode;
    
    private CountryDetailDto countryDetail;
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode2Digit() {
        return code2Digit;
    }

    public void setCode2Digit(String code2Digit) {
        this.code2Digit = code2Digit;
    }
   public String getCode3Digit() {
		return code3Digit;
	}

	public void setCode3Digit(String code3Digit) {
		this.code3Digit = code3Digit;
	}

	public Integer getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(Integer isoCode) {
		this.isoCode = isoCode;
	}

	public String getCallingCode() {
		return callingCode;
	}

	public void setCallingCode(String callingCode) {
		this.callingCode = callingCode;
	}

	public CountryDetailDto getCountryDetail() {
		return countryDetail;
	}

	public void setCountryDetail(CountryDetailDto countryDetail) {
		this.countryDetail = countryDetail;
	}

	public static CountryDto toDto(Country country) {
        CountryDto c = new CountryDto();
        c.setName(country.getName());
        c.setCode2Digit(country.getAlpha2Code());
        c.setCode3Digit(country.getAlpha3Code());
        c.setIsoCode(country.getIsoCode());
        c.setCallingCode(country.getCallingCode());
        
        c.setCountryDetail(CountryDetailDto.toDto(country.getCountryDetail()));
        return c;
    }

}
