package com.nxsang.carrierphone.dao;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.nxsang.carrierphone.domain.Country;

@Repository
public interface CountryDAO extends PagingAndSortingRepository<Country, Integer> {
}
