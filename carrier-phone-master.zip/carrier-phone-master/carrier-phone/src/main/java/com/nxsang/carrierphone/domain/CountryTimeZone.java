package com.nxsang.carrierphone.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "country_timezone")
public class CountryTimeZone implements Serializable {
    
    /**
     * 
     */
    private static final long serialVersionUID = 4647705621492520249L;

    @Id
    @ManyToOne
    @JoinColumn(name = "country_fk")
    private Country country;

    @Id
    @ManyToOne
    @JoinColumn(name = "timezone_fk")
    private TimeZone timeZone;

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public TimeZone getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(TimeZone timeZone) {
        this.timeZone = timeZone;
    }

}
