//package com.nxsang.carrierphone.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.ResponseStatus;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.nxsang.carrierphone.dtos.CountryDTO;
//import com.nxsang.carrierphone.service.CountryService;
//
//@RestController
//@RequestMapping("/carrier")
//public class CarrierPhoneContoller {
//    
//
//    @Autowired
//    private CountryService countryService;
//
//    @RequestMapping(name = "/countries", method = RequestMethod.POST)
//    @ResponseStatus(code = HttpStatus.CREATED)
//    public void addCountry(@RequestBody CountryDTO countryDTO) {
//        countryService.addCountry(countryDTO);
//    }
//}
