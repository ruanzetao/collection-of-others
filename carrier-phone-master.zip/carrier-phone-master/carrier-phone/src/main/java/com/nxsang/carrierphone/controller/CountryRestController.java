package com.nxsang.carrierphone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nxsang.carrierphone.domain.Country;
import com.nxsang.carrierphone.service.CountryService;

@RestController
public class CountryRestController {
 
    @RequestMapping(name = "/welcome",method = RequestMethod.GET)
    @ResponseBody
    public String welcome() {//Welcome page, non-rest
        return "Welcome to RestTemplate Example. hehehe";
    }
    
    @Autowired
    private CountryService countryService;
    // --------------------------------------------
    // CRUD OPERATIONS FOR PARENT RECORDS (country)
    @GetMapping("/country")
    public List getAllTickets() {
        return (List) countryService.findAll();
    }
    
    @PostMapping("/country")
    public Country createCountry(@RequestBody Country country) {
        Country savedCountry=countryService.createCountry(country);
        return savedCountry;
    }
    
    
    
    
    

//    @RequestMapping(name = "/countries", method = RequestMethod.POST)
//    @ResponseStatus(code = HttpStatus.CREATED)
//    public void addCountry(@RequestBody CountryDTO countryDTO) {
//        countryService.createCountry(country);
//    }
}
