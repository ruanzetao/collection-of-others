package com.nxsang.carrierphone.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nxsang.carrierphone.dao.CountryDAO;
import com.nxsang.carrierphone.domain.Country;

import antlr.collections.List;

@Service
public class CountryService {

	@Autowired
	private CountryDAO countryDao;
	
//	public void addCountry(CountryDTO countryDTO) {
//		//Validate country dto.
//		//Convert to Country domain.
//		// 
//		Country country = new Country();
//		countryDao.save(country);
//	}
//	
//
//	public CountryDAO getCountryDao() {
//		return countryDao;
//	}
//
//	public void setCountryDao(CountryDAO countryDao) {
//		this.countryDao = countryDao;
//	}
//	
	
	
	// --------------------------------------------
    // CRUD OPERATIONS FOR PARENT RECORDS (country)
	public Country createCountry(Country country) {
	    return countryDao.save(country);
	}
	
	public List findAll() {
	    return (List) countryDao.findAll();
	}
	
	public Optional<Country> findCountry(int id) {
	    return countryDao.findById(id);
	}
	
	public void deleteById(int id) {
	    countryDao.deleteById(id);
	}
	
}
