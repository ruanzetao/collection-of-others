package com.nxsang.carrierphone.service;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nxsang.carrierphone.domain.CountryDetail;
import com.nxsang.carrierphone.domain.TimeZone;

public class CountryDTO {
    @JsonProperty("pk")
    private Integer pk;
    
    @JsonProperty("name")
    private String name;
    
    @JsonProperty("alpha_2_code")
    private String alpha_2_code;
    
    @JsonProperty("alpha_3_code")
    private String alpha_3_code;
    
    @JsonProperty("iso_code")
    private Integer iso_code;
    
    @JsonProperty("calling_code")
    private String calling_code;
   
    @JsonProperty("created_at")
    private Date created_at;
    
    @JsonProperty("country_detail")
    private CountryDetail country_detail;
    
    @JsonProperty("preferred_timezone_fk")
    private TimeZone preferred_timezone_fk;


    public Integer getPk() {
        return pk;
    }

    public void setPk(Integer pk) {
        this.pk = pk;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlpha_2_code() {
        return alpha_2_code;
    }

    public void setAlpha_2_code(String alpha_2_code) {
        this.alpha_2_code = alpha_2_code;
    }

    public String getAlpha_3_code() {
        return alpha_3_code;
    }

    public void setAlpha_3_code(String alpha_3_code) {
        this.alpha_3_code = alpha_3_code;
    }

    public Integer getIso_code() {
        return iso_code;
    }

    public void setIso_code(Integer iso_code) {
        this.iso_code = iso_code;
    }

    public String getCalling_code() {
        return calling_code;
    }

    public void setCalling_code(String calling_code) {
        this.calling_code = calling_code;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public CountryDetail getCountry_detail() {
        return country_detail;
    }

    public void setCountry_detail(CountryDetail country_detail) {
        this.country_detail = country_detail;
    }

    public TimeZone getPreferred_timezone_fk() {
        return preferred_timezone_fk;
    }

    public void setPreferred_timezone_fk(TimeZone preferred_timezone_fk) {
        this.preferred_timezone_fk = preferred_timezone_fk;
    } 
}
