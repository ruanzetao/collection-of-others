package com.nxsang.carrierphone.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "country")
public class Country implements Serializable {
    private static final long serialVersionUID = -4753507290694457687L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pk")
    private Integer pk;

    @Column(name = "name", unique = true, nullable = false)
    private String name;

    @Column(name = "alpha_2_code", length = 2)
    private String alpha2Code;

    @Column(name = "alpha_3_code", length = 3)
    private String alpha3Code;

    @Column(name = "iso_code")
    private Integer isoCode;

    @Column(name = "calling_code", length = 5)
    private String callingCode;
    
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "preferred_timezone_fk", nullable = true)
    private TimeZone preferredTimeZone;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "country_detail_fk", nullable = true)
    private CountryDetail countryDetail;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "country")
    private Set<AreaCode> areaCodeList = new HashSet<AreaCode>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "country")
    private Set<CarrierMobile> carrierMobiles = new HashSet<CarrierMobile>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "country")
    private Set<CountryTimeZone> countryTimeZones = new HashSet<CountryTimeZone>();

    public Integer getPk() {
        return pk;
    }

    public void setPk(Integer pk) {
        this.pk = pk;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlpha2Code() {
        return alpha2Code;
    }

    public void setAlpha2Code(String alpha2Code) {
        this.alpha2Code = alpha2Code;
    }

    public String getAlpha3Code() {
        return alpha3Code;
    }

    public void setAlpha3Code(String alpha3Code) {
        this.alpha3Code = alpha3Code;
    }

    public Integer getIsoCode() {
        return isoCode;
    }

    public void setIsoCode(Integer isoCode) {
        this.isoCode = isoCode;
    }

    public String getCallingCode() {
        return callingCode;
    }

    public void setCallingCode(String callingCode) {
        this.callingCode = callingCode;
    }

    public TimeZone getPreferredTimeZone() {
        return preferredTimeZone;
    }

    public void setPreferredTimeZone(TimeZone preferredTimeZone) {
        this.preferredTimeZone = preferredTimeZone;
    }

    public CountryDetail getCountryDetail() {
        return countryDetail;
    }

    public void setCountryDetail(CountryDetail countryDetail) {
        this.countryDetail = countryDetail;
    }

    public Set<AreaCode> getAreaCodeList() {
        return areaCodeList;
    }

    public void setAreaCodeList(Set<AreaCode> areaCodeList) {
        this.areaCodeList = areaCodeList;
    }

    public Set<CarrierMobile> getCarrierMobiles() {
        return carrierMobiles;
    }

    public void setCarrierMobiles(Set<CarrierMobile> carrierMobiles) {
        this.carrierMobiles = carrierMobiles;
    }

    public Set<CountryTimeZone> getCountryTimeZones() {
        return countryTimeZones;
    }

    public void setCountryTimeZones(Set<CountryTimeZone> countryTimeZones) {
        this.countryTimeZones = countryTimeZones;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

}
