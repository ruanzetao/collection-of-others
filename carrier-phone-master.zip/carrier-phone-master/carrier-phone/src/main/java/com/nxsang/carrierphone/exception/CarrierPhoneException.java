package com.nxsang.carrierphone.exception;

class CarrierPhoneException {

}
