package com.nxsang.carrierphone.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "timezone")
public class TimeZone implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 4618771996070823180L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pk;

    @Column(name = "abbreviation")
    private String abbr;

    @Column(name = "name")
    private String name;

    @Column(name = "utc_offset")
    private String utcOffset;

    @Column(name = "isdst")
    private Boolean isdst = Boolean.FALSE;
    
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "timeZone", orphanRemoval = true)
    private Set<UTCTimeZone> utcTimeZones = new HashSet<UTCTimeZone>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "timeZone", orphanRemoval = true)
    private Set<CountryTimeZone> countryTimeZoneList = new HashSet<CountryTimeZone>();

    public Integer getPk() {
        return pk;
    }

    public void setPk(Integer pk) {
        this.pk = pk;
    }

    public String getAbbr() {
        return abbr;
    }

    public void setAbbr(String abbr) {
        this.abbr = abbr;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUtcOffset() {
        return utcOffset;
    }

    public void setUtcOffset(String utcOffset) {
        this.utcOffset = utcOffset;
    }

    public Boolean getIsdst() {
        return isdst;
    }

    public void setIsdst(Boolean isdst) {
        this.isdst = isdst;
    }
    
    public Set<UTCTimeZone> getUtcTimeZones() {
        return utcTimeZones;
    }

    public void setUtcTimeZones(Set<UTCTimeZone> utcTimeZones) {
        this.utcTimeZones = utcTimeZones;
    }

    public Set<CountryTimeZone> getCountryTimeZoneList() {
        return countryTimeZoneList;
    }

    public void setCountryTimeZoneList(Set<CountryTimeZone> countryTimeZoneList) {
        this.countryTimeZoneList = countryTimeZoneList;
    }

}
