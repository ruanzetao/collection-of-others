CREATE DATABASE IF NOT EXISTS carrierphone_test;

USE carrierphone_test;
-- SET GLOBAL sql_mode='';

CREATE TABLE IF NOT EXISTS country_detail(
	pk INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	capital VARCHAR(45),
	region VARCHAR(45),
	sub_region VARCHAR(45),
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS timezone(
	pk INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	abbreviation VARCHAR(45),
	name VARCHAR(45),
	utc_offset VARCHAR(45),
	isdst tinyint DEFAULT 0,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS country(
	pk INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(45),
	alpha_2_code VARCHAR(2),
	alpha_3_code VARCHAR(3),
	iso_code INT,
	calling_code VARCHAR(45),
	preferred_timezone_fk INT DEFAULT NULL,
	country_detail_fk INT DEFAULT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT fk_country_countrydetail FOREIGN KEY (country_detail_fk) REFERENCES country_detail(pk),
	CONSTRAINT fk_timezone_country FOREIGN KEY (preferred_timezone_fk) REFERENCES timezone(pk)
);

CREATE TABLE IF NOT EXISTS area_code(
	pk INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	code VARCHAR(45),
	name VARCHAR(45),
	country_fk INT DEFAULT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT fk_country_areacode FOREIGN KEY (country_fk) REFERENCES country(pk)
);

CREATE TABLE IF NOT EXISTS carrier_mobile(
	pk INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(45),
	country_fk INT DEFAULT NULL,
	location VARCHAR(45),
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT fk_country_carriermobile FOREIGN KEY (country_fk) REFERENCES country(pk)
);

CREATE TABLE IF NOT EXISTS phone_extension(
	pk INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	mobile_code VARCHAR(10),
	carrier_fk INT DEFAULT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT fk_carrier_phoneextension FOREIGN KEY (carrier_fk) REFERENCES carrier_mobile(pk)
);

CREATE TABLE IF NOT EXISTS country_timezone(
	country_fk INT NOT NULL,
	timezone_fk INT NOT NULL,
    CONSTRAINT pk_country_timezone PRIMARY KEY (country_fk,timezone_fk),
	CONSTRAINT fk_timezone_countrytimezone FOREIGN KEY (timezone_fk) REFERENCES timezone(pk),
	CONSTRAINT fk_country_countrytimezone FOREIGN KEY (country_fk) REFERENCES country(pk)
);

CREATE TABLE IF NOT EXISTS utc_timezone(
	pk INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	utc VARCHAR(45),
	timezone_fk INT DEFAULT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT fk_timezone_utctimezone FOREIGN KEY (timezone_fk) REFERENCES timezone(pk)
);