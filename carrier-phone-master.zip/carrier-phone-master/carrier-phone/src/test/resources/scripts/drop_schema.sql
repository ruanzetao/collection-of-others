	
DROP DATABASE IF EXISTS carrierphone_test;