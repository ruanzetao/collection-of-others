package com.nxsang.carrierphone.dao;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;
import com.nxsang.carrierphone.config.ConfigITContext;
import com.nxsang.carrierphone.domain.Country;
import com.nxsang.carrierphone.domain.CountryDetail;
import com.nxsang.carrierphone.domain.TimeZone;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ConfigITContext.class })
public class CountryIT {
    @Autowired
    private CountryDAO countryDao;

    @Test
    public void save_country_succcess() {
        // Given
        Country country = new Country();
        // When
        country.setName("Vietnam");
        country.setAlpha2Code("VN");
        country.setAlpha3Code("HTC");
        country.setIsoCode(553);
        country.setCallingCode("BRBCC");

        TimeZone timeZone = new TimeZone(); // timeZone.setPk(1);
        timeZone.setName("Hongkong1");
        timeZone.setAbbr("A123");
        timeZone.setName("A1234");
        timeZone.setUtcOffset("A13");
        country.setPreferredTimeZone(timeZone);

        CountryDetail countryDetail = new CountryDetail(); // countryDetail.setPk(1);
        countryDetail.setCapital("Hongkong2");
        countryDetail.setRegion("HJ3");
        countryDetail.setSubRegion("HY6");
        //countryDetail.setCountry(country);
        country.setCountryDetail(countryDetail);

        countryDao.save(country);

        // Then

        /// Assertions steps
        List<Country> counties = Lists.newArrayList(countryDao.findAll());
        Assert.assertEquals(1, counties.size());
    }

}
