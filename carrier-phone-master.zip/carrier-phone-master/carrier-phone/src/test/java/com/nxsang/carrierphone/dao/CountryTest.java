//package com.nxsang.carrierphone.dao;
//
//import static org.junit.Assert.assertEquals;
//
//import java.util.List;
//
//import org.junit.Assert;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.google.common.collect.Lists;
//import com.nxsang.carrierphone.domain.Country;
//import com.nxsang.carrierphone.domain.CountryDetail;
//
//public class CountryTest {
//    @Autowired
//    private CountryDao countryDao;
//    
//    @Test
//    public void save_country() {
//        Country country = new Country();
//        country.setAlpha2Code("VN");
//        country.setAlpha3Code("HCM");
//        country.setIsoCode(753);
//        
//        assertEquals("VN", country.getAlpha2Code());
//        assertEquals("HCM", country.getAlpha3Code());
//        
//    }
    
    
//    @Test
//    public void save_country_succcess() {
//        //Given
//        Country country = new Country();
//        //When
//        country.setAlpha2Code("VN");
//        country.setAlpha3Code("HTC");
//        country.setIsoCode(553);
//        country.setCallingCode("BRBCC");
//        
//        countryDao.save(country);
//        
//        //Then
//        Country country2=new Country();
//        country2.setIsoCode(778);
//        country2.setAlpha2Code("HK");
//        countryDao.save(country2);
//
//        
//        ///Assertions steps
//        List<Country> counties = Lists.newArrayList(countryDao.findAll());
//        Assert.assertEquals(2,  counties.size());
//    }
// 
//
//    public void save_country_countrydetail_success() {
//        Country country=new Country();
//        CountryDetail countryDetail=new CountryDetail();
//        country.setAlpha2Code("MA");
//        countryDetail.setPk(1);
//        country.setCountryDetail(countryDetail);
//        countryDao.save(country);
//        
//        List<Country> counties = Lists.newArrayList(countryDao.findAll());
//        Assert.assertEquals(1,  counties.size());
//        
//    }
//    
//}
