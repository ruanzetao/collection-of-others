<?php
include_once('controller/LoginController.php');
$c=new LoginController();
$c->getLogin();
?>