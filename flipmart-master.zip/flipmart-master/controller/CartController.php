<?php
include_once("Controller.php");

class CartController extends Controller{

}

?>