<?php
include_once('controller/HomeController.php');
$c=new HomeController();
$c->getIndex();

?>