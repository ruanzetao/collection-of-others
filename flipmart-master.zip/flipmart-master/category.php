<?php
include_once('controller/CategoryController.php');
$c=new CategoryController();
$c->getCategory();

?>